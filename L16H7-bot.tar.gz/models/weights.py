class Weights:
    class Cluster:
        DISTANCE = -3
        RESOURCE_CELLS = 2
        PERIMETER = 2
        PLAYER_UNITS = -3
        PLAYER_CITYTILES = -4
        OPPONENT_UNITS = -2.5
        OPPONENT_CITYTILES = -3.5
